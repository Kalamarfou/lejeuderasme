#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <FMOD/fmod.h>
#include <SDL/SDL_ttf.h> 

int main(int argc, char *argv[])
{
    SDL_Event event;
    SDL_Surface *erasme, *ecran, *fond, *erasme_blup, *erasme_no_blup, *voltaire, *voltaire_blup, *voltaire_no_blup, *transformation, *bulo, *graisse, *anim_tir_erasme, *anim_tir_voltaire;
    SDL_Rect positionerasme, positionfond, positionbulo, positiongraisse[10]={0};
    int continuer=1, jump=0, jump_animation = 0, mode_voltaire=0, jump_count=0, bulo_degaine =0, nombre_de_graisse =0, i=0, j=0, k=0, l=0;
    double now =0, before=0, now2 =0, before2=0;
    FSOUND_SAMPLE *blup = NULL, *voltaire_disponible = NULL, *erasme_disponible = NULL, *plop = NULL, *bulo_sound=NULL;
    
    SDL_Init(SDL_INIT_VIDEO); //SDL
//    TTF_Init();               //texte
    FSOUND_Init(44100, 32, 0);//son
    
    bulo_sound = FSOUND_Sample_Load(FSOUND_FREE, "bulo_sound.wav", 0, 0, 0);
    plop = FSOUND_Sample_Load(FSOUND_FREE, "plop.wav", 0, 0, 0);
    blup = FSOUND_Sample_Load(FSOUND_FREE, "blup.wav", 0, 0, 0);
    voltaire_disponible = FSOUND_Sample_Load(FSOUND_FREE, "voltaire_disponible.wav", 0, 0, 0);
    erasme_disponible = FSOUND_Sample_Load(FSOUND_FREE, "erasme_disponible.wav", 0, 0, 0);
    
    SDL_WM_SetIcon(SDL_LoadBMP("jeu.ico"), NULL); //ic�ne de la fen�tre
    ecran = SDL_SetVideoMode(800, 600, 32, SDL_HWSURFACE | SDL_DOUBLEBUF); //fen�tre 800*600
    SDL_WM_SetCaption("Le jeu d'Erasme >>Rel0aD3d<<", NULL); //nom de la fen�tre
    
    positionerasme.x = 40;
    positionerasme.y = 225;
    
    positionbulo.x = 0;
    positionbulo.y = 0;
    
    positionfond.x = 0;
    positionfond.y = 0;

    SDL_EnableKeyRepeat(1, 1);
    
    fond = SDL_LoadBMP("decor2.bmp");
    erasme = SDL_LoadBMP("erasme.bmp");
    SDL_SetColorKey(erasme, SDL_SRCCOLORKEY, SDL_MapRGB(erasme->format, 0, 0, 255));
    graisse = SDL_LoadBMP("graisse.bmp");
    SDL_SetColorKey(graisse, SDL_SRCCOLORKEY, SDL_MapRGB(graisse->format, 0, 0, 255));
    erasme_blup = SDL_LoadBMP("erasme_blup.bmp");
    SDL_SetColorKey(erasme_blup, SDL_SRCCOLORKEY, SDL_MapRGB(erasme_blup->format, 0, 0, 255));
    erasme_no_blup = SDL_LoadBMP("erasme_no_blup.bmp");
    SDL_SetColorKey(erasme_no_blup, SDL_SRCCOLORKEY, SDL_MapRGB(erasme_no_blup->format, 0, 0, 255));
    voltaire = SDL_LoadBMP("voltaire.bmp");
    SDL_SetColorKey(voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(voltaire->format, 0, 0, 255));
    voltaire_blup = SDL_LoadBMP("voltaire_blup.bmp");
    SDL_SetColorKey(voltaire_blup, SDL_SRCCOLORKEY, SDL_MapRGB(voltaire_blup->format, 0, 0, 255));
    voltaire_no_blup = SDL_LoadBMP("voltaire_no_blup.bmp");
    SDL_SetColorKey(voltaire_no_blup, SDL_SRCCOLORKEY, SDL_MapRGB(voltaire_no_blup->format, 0, 0, 255));
    transformation = SDL_LoadBMP("transformation.bmp");
    SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
    bulo = SDL_LoadBMP("bulo.bmp");
    SDL_SetColorKey(bulo, SDL_SRCCOLORKEY, SDL_MapRGB(bulo->format, 0, 0, 255));
    
    SDL_BlitSurface(fond, NULL, ecran, &positionfond);
    SDL_BlitSurface(erasme, NULL, ecran, &positionerasme);
    SDL_Flip(ecran);  
   
    while (continuer)
    {
          SDL_PollEvent(&event);
          switch(event.type)
          {
              case SDL_QUIT: 
                   continuer = 0;
              break;
              case SDL_KEYDOWN:
                switch(event.key.keysym.sym)
                {
                    case SDLK_RIGHT: // Fl�che droite
                        positionerasme.x=positionerasme.x+2;
                        break;
                    case SDLK_LEFT: // Fl�che gauche
                        positionerasme.x=positionerasme.x-2;
                        break;
                    case SDLK_v:
                         if (jump_count >= 3){
                            FSOUND_PlaySound(FSOUND_FREE, plop);
                            if (mode_voltaire==0){
                            transformation = SDL_LoadBMP("a_transformation/1");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60); 
                            transformation = SDL_LoadBMP("a_transformation/2");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/3");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/4");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/5");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(120);
                            transformation = SDL_LoadBMP("a_transformation/6");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(120);
                            transformation = SDL_LoadBMP("a_transformation/7");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(120);
                            transformation = SDL_LoadBMP("a_transformation/8");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/9");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/10");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            }
                            else if (mode_voltaire==1){
                            transformation = SDL_LoadBMP("a_transformation/10");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60); 
                            transformation = SDL_LoadBMP("a_transformation/9");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/8");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/7");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(120);
                            transformation = SDL_LoadBMP("a_transformation/6");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(120);
                            transformation = SDL_LoadBMP("a_transformation/5");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(120);
                            transformation = SDL_LoadBMP("a_transformation/4");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/3");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/2");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            transformation = SDL_LoadBMP("a_transformation/1");
                            SDL_SetColorKey(transformation, SDL_SRCCOLORKEY, SDL_MapRGB(transformation->format, 0, 0, 255));
                            SDL_BlitSurface(fond, NULL, ecran, &positionfond);
                            SDL_BlitSurface(transformation, NULL, ecran, &positionerasme);
                            SDL_Flip(ecran);
                            SDL_Delay(60);
                            }
                         if (mode_voltaire ==0 && jump_count >= 3)
                            mode_voltaire =1;
                         else if (mode_voltaire ==1 && jump_count >= 3)
                            mode_voltaire =0;
                         jump_count = 0;
                         }                           
                         break;
                    case SDLK_b:
                         now2 = SDL_GetTicks();
                         if (bulo_degaine==1 && now2 - before2 > 5000){
                            bulo_degaine=0;
                            before2 =now2;
                            }
                         else if (bulo_degaine==0 && now2 - before2 > 5000){
                              bulo_degaine=1;
                              FSOUND_PlaySound(FSOUND_FREE, bulo_sound);
                              before2 =now2;
                              }
                         break;                            
                         
                      case SDLK_q:
                         now = SDL_GetTicks();
                         if (nombre_de_graisse < 10 && now - before > 1000 && mode_voltaire==0){                   
                            nombre_de_graisse++;
                            positiongraisse[nombre_de_graisse].x= positionerasme.x +160;
                            positiongraisse[nombre_de_graisse].y= positionerasme.y +151;
                            before=now;
                            k=1;
                            }
                         if (nombre_de_graisse == 10 && now - before > 1000 && mode_voltaire==0){
                            nombre_de_graisse=1;
                            positiongraisse[nombre_de_graisse].x= positionerasme.x +160;
                            positiongraisse[nombre_de_graisse].y= positionerasme.y +151;
                            before=now;
                            j=1;
                            k=1;
                            }
                         if (mode_voltaire==1)
                            k=1;
                         break;
                      case SDLK_SPACE:
                         if (positionerasme.y==225){
                            jump = 1;
                            FSOUND_PlaySound(FSOUND_FREE, blup);
                            jump_count++;
                            }
                         if (jump_count == 3 && mode_voltaire ==0)
                            FSOUND_PlaySound(FSOUND_FREE, voltaire_disponible);
                         else if (jump_count == 3 && mode_voltaire == 1)
                            FSOUND_PlaySound(FSOUND_FREE, erasme_disponible);
                         break;
                     }
           }
           
           if (jump==1 && positionerasme.y>=100)
                positionerasme.y--;
           else if (jump==1 && positionerasme.y<100)
                jump =-1;
           else if (jump==-1 && positionerasme.y<=225)
                positionerasme.y++;
           else if (jump==-1 && positionerasme.y>225)
           {
                positionerasme.y=225;
                jump=0;
           }
           
           
           SDL_BlitSurface(fond, NULL, ecran, &positionfond);
           
           
           if (k != 0 && mode_voltaire==0){
                 if (k==1){
                       l=0;
                       k=2;
                       SDL_FreeSurface(anim_tir_erasme);
                       anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque1.bmp");
                       SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                       }
                else if (k==2){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>12){
                                    SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque2.bmp");
                                  SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=3;
                                   l=0;
                                   }
                           }
                else if (k==3){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>12){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque3.bmp");
                                   SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=4;
                                   l=0;
                                   }
                           }
                else if (k==4){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque4.bmp");
                                   SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=5;
                                   l=0;
                                   }
                           }
                else if (k==5){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque5.bmp");
                                   SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=6;
                                   l=0;
                                   }
                           }
                else if (k==6){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque6.bmp");
                                   SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=7;
                                   l=0;
                                   }
                           }
                else if (k==7){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque7.bmp");
                                   SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=8;
                                   l=0;
                                   }
                           }
                else if (k==8){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_erasme = SDL_LoadBMP("a_erasme/erasmeattaque8.bmp");
                                   SDL_SetColorKey(anim_tir_erasme, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_erasme->format, 0, 0, 255));
                                   k=9;
                                   l=0;
                                   }
                           }
                else if (k==9){
                           SDL_BlitSurface(anim_tir_erasme, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   k=0;
                                   l=0;
                                   }
                           }
                             
                   }
                   
                   
                   
                   
                   
                   
             if (k != 0 && mode_voltaire==1){
                 if (k==1){
                       l=0;
                       k=2;
//                       SDL_FreeSurface(anim_tir_voltaire);
                       anim_tir_voltaire = SDL_LoadBMP("a_voltaire/attaquevoltaire1.bmp");
                       SDL_SetColorKey(anim_tir_voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_voltaire->format, 0, 0, 255));
                       }
                else if (k==2){
                           SDL_BlitSurface(anim_tir_voltaire, NULL, ecran, &positionerasme);
                           l++;
                           if (l>12){
                                    SDL_FreeSurface(anim_tir_voltaire);
                                   anim_tir_voltaire = SDL_LoadBMP("a_voltaire/attaquevoltaire2.bmp");
                                  SDL_SetColorKey(anim_tir_voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_voltaire->format, 0, 0, 255));
                                   k=3;
                                   l=0;
                                   }
                           }
                else if (k==3){
                           SDL_BlitSurface(anim_tir_voltaire, NULL, ecran, &positionerasme);
                           l++;
                           if (l>12){
                                   SDL_FreeSurface(anim_tir_voltaire);
                                   anim_tir_voltaire = SDL_LoadBMP("a_voltaire/attaquevoltaire3.bmp");
                                   SDL_SetColorKey(anim_tir_voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_voltaire->format, 0, 0, 255));
                                   k=4;
                                   l=0;
                                   }
                           }
                else if (k==4){
                           SDL_BlitSurface(anim_tir_voltaire, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_voltaire);
                                   anim_tir_voltaire = SDL_LoadBMP("a_voltaire/attaquevoltaire4.bmp");
                                   SDL_SetColorKey(anim_tir_voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_voltaire->format, 0, 0, 255));
                                   k=5;
                                   l=0;
                                   }
                           }
                else if (k==5){
                           SDL_BlitSurface(anim_tir_voltaire, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_erasme);
                                   anim_tir_voltaire = SDL_LoadBMP("a_voltaire/attaquevoltaire5.bmp");
                                   SDL_SetColorKey(anim_tir_voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_voltaire->format, 0, 0, 255));
                                   k=6;
                                   l=0;
                                   }
                           }
                else if (k==6){
                           SDL_BlitSurface(anim_tir_voltaire, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   SDL_FreeSurface(anim_tir_voltaire);
                                   anim_tir_voltaire = SDL_LoadBMP("a_voltaire/attaquevoltaire6.bmp");
                                   SDL_SetColorKey(anim_tir_voltaire, SDL_SRCCOLORKEY, SDL_MapRGB(anim_tir_voltaire->format, 0, 0, 255));
                                   k=7;
                                   l=0;
                                   }
                           }
                else if (k==7){
                           SDL_BlitSurface(anim_tir_voltaire, NULL, ecran, &positionerasme);
                           l++;
                           if (l>8){
                                   k=0;
                                   l=0;
                                   }
                           }
                             
                   }
                   
                   
                   
                   
                   
                   
                   
           else if (jump == 1 && mode_voltaire==0)
              SDL_BlitSurface(erasme_blup, NULL, ecran, &positionerasme);
           else if (jump == -1 && mode_voltaire==0)
              SDL_BlitSurface(erasme_no_blup, NULL, ecran, &positionerasme);
           else if (jump ==0 && mode_voltaire==0)
               SDL_BlitSurface(erasme, NULL, ecran, &positionerasme);
           else if (jump == 1 && mode_voltaire==1)
              SDL_BlitSurface(voltaire_blup, NULL, ecran, &positionerasme);
           else if (jump == -1 && mode_voltaire==1)
              SDL_BlitSurface(voltaire_no_blup, NULL, ecran, &positionerasme);
           else if (jump ==0 && mode_voltaire==1)
               SDL_BlitSurface(voltaire, NULL, ecran, &positionerasme);
           if (nombre_de_graisse >0)
           {
              i=0;
              if (j==1){
                                 while ( i < 10)
                                       {
                                        i++;
                                        SDL_BlitSurface(graisse, NULL, ecran, &positiongraisse[i]);
                                        positiongraisse[i].x++;                  
                                        }
                        }
              else {
                 while ( i < nombre_de_graisse)
                       {
                         i++;
                         SDL_BlitSurface(graisse, NULL, ecran, &positiongraisse[i]);
                         positiongraisse[i].x++;                  
                       }
                   }
           }
           
           if (bulo_degaine==1)
           {
              if (jump ==0){
                 positionbulo.x= positionerasme.x + 154;
                 positionbulo.y= positionerasme.y + 151;
                 SDL_BlitSurface(bulo, NULL, ecran, &positionbulo);
                 }
              else if (jump==1){
                 positionbulo.x= positionerasme.x + 73;
                 positionbulo.y= positionerasme.y + 226;
                 SDL_BlitSurface(bulo, NULL, ecran, &positionbulo);
                 }
              else if (jump ==-1){
                 positionbulo.x= positionerasme.x + 51;
                 positionbulo.y= positionerasme.y + 79;
                 SDL_BlitSurface(bulo, NULL, ecran, &positionbulo);
                   }
           }
           SDL_Flip(ecran);  
    }
    SDL_FreeSurface(erasme);
    SDL_FreeSurface(ecran);
    SDL_Quit();
    FSOUND_Close();
}
